-- Criação do banco de dados


create database jornadaDB;
USE jornadaDB;

-- Tabela principal: DEMANDA
CREATE TABLE Tempo (
    idTempo INT PRIMARY KEY AUTO_INCREMENT,
    tempoEspera DOUBLE,
    media_atendimento DOUBLE
);



CREATE TABLE Local (
    idLocal INT PRIMARY KEY AUTO_INCREMENT,
    endereco varchar(128),
    regiao VARCHAR(100),
    consumo_medio_regiao DOUBLE,
    distancia_sede DOUBLE
);

CREATE TABLE veiculo (
  idVeiculo INT AUTO_INCREMENT PRIMARY KEY,
  marca VARCHAR(100),
  tipoVeiculo VARCHAR(100),
  custoPKM DOUBLE,
  anoVeiculo INT
);

CREATE TABLE peca (
  idPeca INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100),
  custo DOUBLE
);



CREATE TABLE TipoChamado (
    idTipo INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(255)
);

CREATE TABLE demandas (
    idDemanda INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(255),
    tempo_id INT,
    peca_id INT,
    local_id INT,
    veiculo_id INT,
     custos double,
    tipo_id INT,
    pontos DOUBLE,
    prioridade VARCHAR(50),
    FOREIGN KEY (tempo_id) REFERENCES Tempo(idTempo),
    FOREIGN KEY (peca_id) REFERENCES Peca(idPeca),
    FOREIGN KEY (local_id) REFERENCES Local(idLocal),
    FOREIGN KEY (veiculo_id) REFERENCES Veiculo(idVeiculo),
    FOREIGN KEY (tipo_id) REFERENCES TipoChamado(idTipo)
);
CREATE TABLE custos (
	idDemanda int,
  idCustos int primary key auto_increment,
  custoMaoObra DOUBLE,
  custoHoraParada DOUBLE,
  veiculo_id INT,
  FOREIGN KEY (veiculo_id) REFERENCES veiculo(idVeiculo),
  foreign key(idDemanda) references demandas(idDemanda)
);
CREATE TABLE demanda_peca (
    idDemanda INT,
    idPeca INT,
    FOREIGN KEY (idDemanda) REFERENCES demandas(idDemanda),
    FOREIGN KEY (idPeca) REFERENCES peca(idPeca)
);
select * from demandas;
DESCRIBE custos;
select * from custos;
